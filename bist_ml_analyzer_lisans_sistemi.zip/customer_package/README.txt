Müşteri teslim paketi örneği. Yayın sonrası resmi panel adresini index.html dosyasına ekle. Gerçek analiz ve lisans kontrolü merkezi sunucudadır.
