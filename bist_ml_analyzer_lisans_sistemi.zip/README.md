# BIST ML Analyzer — IBAN ve lisans yönetimi

Tarayıcı tabanlı müşteri paneli, ayrı yönetici paneli, manuel IBAN ödeme kaydı ve sunucu tarafında lisans kontrolü içeren başlangıç sürümü.

- Müşteri paneli: `/` — e-posta/parola girişi ve 1/5/20 işlem günlük model analizi.
- Yönetici paneli: `/admin` — müşteri oluşturma, ödeme kaydı, lisans etkinleştirme/askıya alma/iptal ve bitiş tarihi.
- Sağlık kontrolü: `/health`.

## Yayına alma
`render.yaml` Render için örnek dağıtım tanımıdır. GitHub deposuna yükleyip Render'da Blueprint olarak dağıt. Yayın sonrası Render ortam değişkenlerinde `ADMIN_KEY` ve `SESSION_SECRET` değerlerini güvenli tut; `DATABASE_PATH=/var/data/bist_ml.sqlite3` kalıcı disk yoluyla eşleşmeli. HTTPS'yi doğrula.

İlk müşteri akışı: yönetici panelinden müşteri ve geçici parola oluştur; IBAN ödemesini bankadan doğrula; ödeme kaydı ekle; lisansı `active` yap; panel adresini ve giriş bilgilerini e-postayla ilet.

`customer_package/index.html` teslim paketi örneğidir. Gerçek analiz ve lisans doğrulaması merkezi sunucuda çalışır; tek başına statik HTML dosyası gerçek analiz veya lisans denetimi sağlayamaz. Yayın adresini bu dosyaya ekle. Bu sürüm otomatik e-posta göndermez.

## Güvenlik ve ticari kullanım uyarıları
Bu başlangıç kodu bağımsız güvenlik denetiminden geçmemiştir. Yönetici erişimi API anahtarı tabanlıdır; halka açık ticari kullanımdan önce yönetici kullanıcı/parola + MFA, rate limit, denetim kayıtları, otomatik yedek ve güvenlik testi eklenmelidir. Lisans askıya alınınca sunucuya bağlı analiz istekleri engellenir; daha önce indirilmiş statik dosyaların görüntülenmesini bütünüyle engellemek mümkün değildir. Veri kaynağı yfinance/Yahoo Finance olduğundan ticari kullanım koşullarını ve veri gecikmesini kontrol et. Model çıktısı yatırım tavsiyesi veya getiri garantisi değildir. Canlıya çıkmadan önce KVKK, tüketici ve sermaye piyasası mevzuatı için uzman görüşü al.
