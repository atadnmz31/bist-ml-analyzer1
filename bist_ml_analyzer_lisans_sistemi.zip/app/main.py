import os, sqlite3, secrets, hashlib, hmac
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import pandas as pd
import yfinance as yf
from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, EmailStr, Field
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

DB_PATH=os.getenv('DATABASE_PATH','data/bist_ml.sqlite3')
ADMIN_KEY=os.getenv('ADMIN_KEY','')
SESSION_SECRET=os.getenv('SESSION_SECRET','')
serializer=URLSafeTimedSerializer(SESSION_SECRET) if SESSION_SECRET else None
app=FastAPI(title='BIST ML Analyzer')
Path(DB_PATH).parent.mkdir(parents=True,exist_ok=True)

def db():
 c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row
 c.execute("CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,license_status TEXT NOT NULL DEFAULT 'pending',expires_at TEXT,paid_amount REAL NOT NULL DEFAULT 0,notes TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL)")
 c.execute("CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER NOT NULL,amount REAL NOT NULL,paid_at TEXT NOT NULL,note TEXT NOT NULL DEFAULT '')")
 c.commit(); return c

def hashpw(p,s=None):
 s=s or secrets.token_hex(16)
 return s+'$'+hashlib.pbkdf2_hmac('sha256',p.encode(),s.encode(),310000).hex()
def checkpw(p,v):
 try:
  s,d=v.split('$',1); return hmac.compare_digest(hashpw(p,s).split('$',1)[1],d)
 except Exception: return False
def admin(x_admin_key:str=Header(default='')):
 if not ADMIN_KEY or not hmac.compare_digest(x_admin_key,ADMIN_KEY): raise HTTPException(401,'Yönetici anahtarı hatalı.')
def customer(authorization:str=Header(default='')):
 if not serializer: raise HTTPException(503,'SESSION_SECRET ayarı eksik.')
 if not authorization.startswith('Bearer '): raise HTTPException(401,'Giriş yapmalısın.')
 try: data=serializer.loads(authorization[7:],max_age=1209600)
 except (BadSignature,SignatureExpired): raise HTTPException(401,'Oturum geçersiz veya süresi dolmuş.')
 with db() as c: r=c.execute('SELECT * FROM customers WHERE id=?',(data.get('id'),)).fetchone()
 if not r: raise HTTPException(401,'Hesap bulunamadı.')
 if r['license_status']!='active': raise HTTPException(403,'Lisans aktif değil veya erişim askıya alınmış.')
 if r['expires_at']:
  try:
   if datetime.fromisoformat(r['expires_at']) < datetime.now(timezone.utc): raise HTTPException(403,'Lisans süren dolmuş.')
  except ValueError: raise HTTPException(403,'Lisans bitiş tarihi hatalı.')
 return r

class Login(BaseModel):
 email:EmailStr
 password:str=Field(min_length=8,max_length=200)
class NewCustomer(BaseModel):
 name:str=Field(min_length=1,max_length=100)
 email:EmailStr
 temporary_password:str=Field(min_length=10,max_length=200)
 expires_at:str=''
 notes:str=''
class License(BaseModel):
 status:str
 expires_at:str=''
 notes:str=''
class Payment(BaseModel):
 amount:float=Field(gt=0)
 note:str=''
class Analyze(BaseModel):
 symbol:str=Field(min_length=1,max_length=20)
 horizon:int=Field(default=5,ge=1,le=20)

@app.get('/',response_class=HTMLResponse)
def home(): return HTMLResponse(CUSTOMER_HTML)
@app.get('/admin',response_class=HTMLResponse)
def adminpage(): return HTMLResponse(ADMIN_HTML)
@app.get('/health')
def health(): return {'ok':True}
@app.post('/api/login')
def login(b:Login):
 with db() as c: r=c.execute('SELECT * FROM customers WHERE lower(email)=lower(?)',(b.email,)).fetchone()
 if not r or not checkpw(b.password,r['password_hash']): raise HTTPException(401,'E-posta veya parola hatalı.')
 if r['license_status']!='active': raise HTTPException(403,'Lisans aktif değil veya askıya alınmış.')
 if r['expires_at']:
  try:
   if datetime.fromisoformat(r['expires_at']) < datetime.now(timezone.utc): raise HTTPException(403,'Lisans süren dolmuş.')
  except ValueError: raise HTTPException(403,'Lisans bitiş tarihi hatalı.')
 if not serializer: raise HTTPException(503,'SESSION_SECRET ayarı eksik.')
 return {'token':serializer.dumps({'id':r['id'],'email':r['email']}),'name':r['name'],'expires_at':r['expires_at']}
@app.get('/api/me')
def me(c=Depends(customer)): return {'name':c['name'],'email':c['email'],'expires_at':c['expires_at']}
@app.post('/api/analyze')
def analyze(b:Analyze,c=Depends(customer)):
 symbol=b.symbol.upper().strip()
 if not symbol.replace('.','').isalnum(): raise HTTPException(400,'Hisse kodunu kontrol et.')
 ticker=symbol if symbol.endswith('.IS') else symbol+'.IS'
 try:
  df=yf.download(ticker,period='5y',interval='1d',auto_adjust=True,progress=False,threads=False)
  if df.empty or len(df)<260: raise HTTPException(404,'Yeterli tarihsel veri bulunamadı.')
  if isinstance(df.columns,pd.MultiIndex): df.columns=df.columns.get_level_values(0)
  df=df[['Open','High','Low','Close','Volume']].dropna().copy(); close=df['Close']
  df['ret1']=close.pct_change(); df['ret5']=close.pct_change(5); df['ret20']=close.pct_change(20)
  df['volatility']=df['ret1'].rolling(20).std(); df['ma5_gap']=close/close.rolling(5).mean()-1
  df['ma20_gap']=close/close.rolling(20).mean()-1; df['ma60_gap']=close/close.rolling(60).mean()-1
  df['volume_change']=df['Volume'].pct_change().replace([np.inf,-np.inf],np.nan)
  features=['ret1','ret5','ret20','volatility','ma5_gap','ma20_gap','ma60_gap','volume_change']
  dataset=df[features].replace([np.inf,-np.inf],np.nan).copy()
  dataset['target']=(close.shift(-b.horizon)>close).astype(int); dataset=dataset.dropna()
  if len(dataset)<200: raise HTTPException(422,'Model için yeterli veri yok.')
  train=dataset.iloc[:-b.horizon]; split=int(len(train)*.8)
  if split<100: raise HTTPException(422,'Model için yeterli veri yok.')
  model=RandomForestClassifier(n_estimators=200,max_depth=7,min_samples_leaf=5,class_weight='balanced',random_state=42,n_jobs=-1)
  model.fit(train[features].iloc[:split],train['target'].iloc[:split])
  acc=accuracy_score(train['target'].iloc[split:],model.predict(train[features].iloc[split:]))
  model.fit(train[features],train['target'])
  latest=df[features].replace([np.inf,-np.inf],np.nan).dropna().iloc[[-1]]
  probs=model.predict_proba(latest)[0]; classes=list(model.classes_)
  up=float(probs[classes.index(1)]) if 1 in classes else 0
  return {'symbol':ticker,'horizon':b.horizon,'last_price':round(float(close.iloc[-1]),4),'up_probability':round(up*100,2),'down_probability':round((1-up)*100,2),'holdout_accuracy':round(float(acc)*100,2),'data_date':str(df.index[-1].date()),'disclaimer':'Model çıktısıdır; yatırım tavsiyesi veya getiri garantisi değildir.'}
 except HTTPException: raise
 except Exception as e: raise HTTPException(502,'Veri/model hatası: '+type(e).__name__)

@app.get('/api/admin/customers',dependencies=[Depends(admin)])
def list_customers():
 with db() as c: rows=c.execute('SELECT id,name,email,license_status,expires_at,paid_amount,notes,created_at FROM customers ORDER BY id DESC').fetchall()
 return [dict(r) for r in rows]
@app.post('/api/admin/customers',dependencies=[Depends(admin)])
def add_customer(b:NewCustomer):
 with db() as c:
  try:
   cur=c.execute("INSERT INTO customers(name,email,password_hash,license_status,expires_at,notes,created_at) VALUES(?,?,?,'pending',?,?,?)",(b.name.strip(),b.email.lower(),hashpw(b.temporary_password),b.expires_at or None,b.notes,datetime.now(timezone.utc).isoformat())); c.commit()
   return {'id':cur.lastrowid,'message':'Müşteri eklendi; ödeme doğrulanınca lisansı etkinleştir.'}
  except sqlite3.IntegrityError: raise HTTPException(409,'Bu e-posta zaten kayıtlı.')
@app.patch('/api/admin/customers/{cid}/license',dependencies=[Depends(admin)])
def set_license(cid:int,b:License):
 if b.status not in ('active','suspended','revoked','pending'): raise HTTPException(400,'Geçersiz lisans durumu.')
 with db() as c:
  cur=c.execute('UPDATE customers SET license_status=?,expires_at=?,notes=? WHERE id=?',(b.status,b.expires_at or None,b.notes,cid)); c.commit()
  if not cur.rowcount: raise HTTPException(404,'Müşteri bulunamadı.')
 return {'ok':True,'license_status':b.status}
@app.post('/api/admin/customers/{cid}/payments',dependencies=[Depends(admin)])
def payment(cid:int,b:Payment):
 with db() as c:
  r=c.execute('SELECT paid_amount FROM customers WHERE id=?',(cid,)).fetchone()
  if not r: raise HTTPException(404,'Müşteri bulunamadı.')
  c.execute('INSERT INTO payments(customer_id,amount,paid_at,note) VALUES(?,?,?,?)',(cid,b.amount,datetime.now(timezone.utc).isoformat(),b.note))
  c.execute('UPDATE customers SET paid_amount=paid_amount+? WHERE id=?',(b.amount,cid)); c.commit()
 return {'ok':True,'new_total_paid':round(float(r['paid_amount'])+b.amount,2)}

CUSTOMER_HTML = r'''<!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BIST ML Analyzer</title><style>*{box-sizing:border-box}body{margin:0;background:#0a0f1c;color:#edf3ff;font:16px system-ui}main{max-width:850px;margin:auto;padding:24px 16px}.card{background:#121b2c;border:1px solid #26354b;border-radius:16px;padding:20px;margin:14px 0}input,select,button{width:100%;padding:13px;border-radius:9px;border:1px solid #34445b;background:#0b1322;color:#edf3ff;font:inherit;margin:6px 0 12px}button{background:#2563eb;border:0;font-weight:bold}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}.metric{background:#0b1322;padding:16px;border-radius:12px}.metric strong{display:block;font-size:26px;margin-top:8px}.muted{color:#9aabc2}.hidden{display:none}.msg{white-space:pre-wrap;background:#17263d;padding:10px;border-radius:8px}</style><main><h1>📈 BIST ML Analyzer</h1><p class="muted">Makine öğrenmesi destekli hisse analizi</p><section id="login" class="card"><h2>Giriş yap</h2><label>E-posta</label><input id="email" type="email"><label>Parola</label><input id="password" type="password"><button onclick="login()">Giriş yap</button><div id="loginMsg" class="msg hidden"></div></section><section id="panel" class="hidden"><div class="card"><button style="width:auto;float:right" onclick="logout()">Çıkış</button><h2 id="welcome">Analiz paneli</h2><p id="expiry" class="muted"></p></div><div class="card"><h2>Hisse analizi</h2><label>BIST kodu</label><input id="symbol" placeholder="THYAO"><label>Tahmin ufku</label><select id="horizon"><option value="1">1 işlem günü</option><option value="5" selected>5 işlem günü</option><option value="20">20 işlem günü</option></select><button onclick="analyze()">Analiz et</button><div id="resultMsg" class="msg hidden"></div><div id="result" class="hidden"><div class="grid"><div class="metric">Yükseliş olasılığı<strong id="up"></strong></div><div class="metric">Düşüş olasılığı<strong id="down"></strong></div><div class="metric">Son kapanış<strong id="price"></strong></div><div class="metric">Holdout doğruluğu<strong id="accuracy"></strong></div></div><p id="meta" class="muted"></p><p id="disclaimer" class="muted"></p></div></div></section><p class="muted">Bu model yatırım tavsiyesi değildir; geçmiş performans geleceği garanti etmez.</p></main><script>let token=localStorage.getItem('bist_token');function showmsg(id,t){let e=document.getElementById(id);e.textContent=t;e.classList.remove('hidden')}async function api(path,opts={}){opts.headers={...(opts.headers||{}),...(token?{Authorization:'Bearer '+token}:{})};if(opts.body)opts.headers['Content-Type']='application/json';let r=await fetch(path,opts);let d=await r.json().catch(()=>({detail:'Yanıt okunamadı'}));if(!r.ok)throw Error(d.detail||'İşlem başarısız');return d}async function login(){try{let d=await api('/api/login',{method:'POST',body:JSON.stringify({email:email.value,password:password.value})});token=d.token;localStorage.setItem('bist_token',token);await showpanel()}catch(e){showmsg('loginMsg',e.message)}}async function showpanel(){try{let d=await api('/api/me');document.getElementById('login').classList.add('hidden');document.getElementById('panel').classList.remove('hidden');welcome.textContent='Merhaba, '+d.name;expiry.textContent=d.expires_at?'Lisans bitişi: '+d.expires_at:'Lisans süresiz'}catch(e){logout();showmsg('loginMsg',e.message)}}function logout(){token=null;localStorage.removeItem('bist_token');document.getElementById('panel').classList.add('hidden');document.getElementById('login').classList.remove('hidden')}async function analyze(){result.classList.add('hidden');try{let d=await api('/api/analyze',{method:'POST',body:JSON.stringify({symbol:symbol.value,horizon:Number(horizon.value)})});up.textContent=d.up_probability+'%';down.textContent=d.down_probability+'%';price.textContent=d.last_price.toLocaleString('tr-TR');accuracy.textContent=d.holdout_accuracy+'%';meta.textContent=d.symbol+' · '+d.horizon+' işlem günü · Veri tarihi: '+d.data_date;disclaimer.textContent=d.disclaimer;result.classList.remove('hidden')}catch(e){showmsg('resultMsg',e.message)}}if(token)showpanel();</script></html>'''

ADMIN_HTML = r'''<!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BIST Yönetici</title><style>*{box-sizing:border-box}body{margin:0;background:#0a0f1c;color:#edf3ff;font:15px system-ui}main{max-width:1100px;margin:auto;padding:20px 14px}.card{background:#121b2c;border:1px solid #26354b;border-radius:14px;padding:16px;margin:14px 0}input,select,button{width:100%;padding:11px;border-radius:9px;border:1px solid #34445b;background:#0b1322;color:#edf3ff;margin:5px 0 10px;font:inherit}button{background:#2563eb;border:0;font-weight:bold}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}.muted{color:#9aabc2}.hidden{display:none}.msg{white-space:pre-wrap;background:#17263d;padding:10px;border-radius:8px}table{border-collapse:collapse;width:100%;min-width:700px}td,th{padding:9px;border-bottom:1px solid #34445b;text-align:left}.wrap{overflow:auto}</style><main><h1>BIST ML Analyzer — Yönetici</h1><p class="muted">IBAN ödemesini bankadan doğrula, sonra lisansı etkinleştir.</p><div class="card"><label>Sunucudaki ADMIN_KEY</label><input id="key" type="password"><button onclick="load()">Yönetici paneline gir</button><div id="msg" class="msg hidden"></div></div><section id="admin" class="hidden"><div class="card"><h2>Müşteri ekle</h2><div class="grid"><div><label>Ad soyad</label><input id="name"></div><div><label>E-posta</label><input id="email" type="email"></div><div><label>Geçici parola (min. 10 karakter)</label><input id="pw"></div><div><label>Lisans bitişi (ISO; ör. 2026-12-31T23:59:00+00:00)</label><input id="expires"></div></div><label>Not</label><input id="notes"><button onclick="add()">Müşteri oluştur</button></div><div class="card"><h2>Müşteri listesi</h2><button onclick="load()">Yenile</button><div class="wrap"><table><thead><tr><th>ID</th><th>Müşteri</th><th>Durum</th><th>Bitiş</th><th>Ödenen</th><th>Seç</th></tr></thead><tbody id="rows"></tbody></table></div></div><div class="card"><h2>Lisans ve ödeme işlemleri</h2><label>Müşteri ID</label><input id="cid" type="number"><div class="grid"><div><label>Durum</label><select id="status"><option value="active">Aktif et</option><option value="suspended">Askıya al</option><option value="revoked">İptal et</option><option value="pending">Beklemede</option></select></div><div><label>Yeni bitiş tarihi (ISO, boşsa süresiz)</label><input id="newExpiry"></div></div><label>Not</label><input id="newNotes"><button onclick="setlicense()">Lisans durumunu kaydet</button><hr><h3>Ödeme kaydı</h3><div class="grid"><div><label>Tutar TL</label><input id="amount" type="number" min=".01" step=".01"></div><div><label>Açıklama</label><input id="paymentNote"></div></div><button onclick="pay()">Ödemeyi kaydet</button></div></section></main><script>let adminKey='';async function call(path,method='GET',body=null){let r=await fetch(path,{method,headers:{'X-Admin-Key':adminKey,...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});let d=await r.json().catch(()=>({detail:'Yanıt okunamadı'}));if(!r.ok)throw Error(d.detail||'İşlem başarısız');return d}function say(t){msg.textContent=t;msg.classList.remove('hidden')}async function load(){adminKey=key.value;try{let a=await call('/api/admin/customers');admin.classList.remove('hidden');rows.innerHTML='';for(let c of a){let tr=document.createElement('tr');for(let v of [c.id,c.name+' · '+c.email,c.license_status,c.expires_at||'Süresiz',Number(c.paid_amount).toLocaleString('tr-TR')+' TL']){let td=document.createElement('td');td.textContent=v;tr.appendChild(td)}let td=document.createElement('td'),b=document.createElement('button');b.textContent='Seç';b.onclick=()=>{cid.value=c.id;status.value=c.license_status;newExpiry.value=c.expires_at||'';newNotes.value=c.notes||''};td.appendChild(b);tr.appendChild(td);rows.appendChild(tr)}say('Müşteri sayısı: '+a.length)}catch(e){say(e.message)}}async function add(){try{let d=await call('/api/admin/customers','POST',{name:name.value,email:email.value,temporary_password:pw.value,expires_at:expires.value,notes:notes.value});say(d.message+' ID: '+d.id);load()}catch(e){say(e.message)}}async function setlicense(){try{let d=await call('/api/admin/customers/'+cid.value+'/license','PATCH',{status:status.value,expires_at:newExpiry.value,notes:newNotes.value});say('Lisans güncellendi: '+d.license_status);load()}catch(e){say(e.message)}}async function pay(){try{let d=await call('/api/admin/customers/'+cid.value+'/payments','POST',{amount:Number(amount.value),note:paymentNote.value});say('Ödeme kaydedildi. Toplam: '+d.new_total_paid+' TL');load()}catch(e){say(e.message)}}</script></html>'''
